var searchData=
[
  ['gaussianfilter_0',['GaussianFilter',['../class_image.html#a7357b545059457d5867a8bc89a168c57',1,'Image']]],
  ['getchannels_1',['getChannels',['../class_image.html#a074132850b855562d55cd7246a993141',1,'Image::getChannels()'],['../class_volume.html#a5a445744411b9ff7fcf26931c4e6afe9',1,'Volume::getChannels()']]],
  ['getexist_2',['getExist',['../class_image.html#a14868bae168814b70240f6f36efe9c81',1,'Image::getExist()'],['../class_volume.html#afcb788195c9acac7ad533ae2109c4c85',1,'Volume::getExist()']]],
  ['getfolderpath_3',['getFolderPath',['../class_volume.html#a309d73c2510fdaaeea51db6cf9f84975',1,'Volume']]],
  ['getheight_4',['getHeight',['../class_image.html#aa4e1f064e5e1f3f04ad605408f1ec3af',1,'Image::getHeight()'],['../class_volume.html#a7ac4d95f8f1ba5f1194c1c416efc1624',1,'Volume::getHeight()']]],
  ['getimages_5',['getImages',['../class_volume.html#a87af43ee6949bb49d43e1b704d5f157c',1,'Volume']]],
  ['getpath_6',['getPath',['../class_image.html#a885989eb723cb0a1fc0555c7e8de817e',1,'Image']]],
  ['getwidth_7',['getWidth',['../class_image.html#af2720a072812763395512fc3c8c21362',1,'Image::getWidth()'],['../class_volume.html#a04bbfbb1c84cb96c9eb879d88e85a00e',1,'Volume::getWidth()']]],
  ['grayscale_8',['Grayscale',['../class_image.html#a574fddf6258210ca7aa310439d9505f7',1,'Image']]],
  ['group_20project_9',['Advanced Programming Group Project',['../md__r_e_a_d_m_e.html',1,'']]]
];
