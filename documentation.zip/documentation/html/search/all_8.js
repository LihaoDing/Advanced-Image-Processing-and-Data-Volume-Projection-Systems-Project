var searchData=
[
  ['filter_0',['Filter',['../class_filter.html',1,'Filter'],['../class_filter.html#ad15994c30d497afd567a6445446a249e',1,'Filter::Filter()']]],
  ['for_20using_1',['Instruction for using',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
