var searchData=
[
  ['1_201_20start_20model_20choose_0',['1.1 Start - model choose',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['1_202_20start_20upload_20data_1',['1.2 Start - Upload data',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['1_202d_20menu_2',['2.1 2D MENU',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['1_20start_3',['1. START',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
