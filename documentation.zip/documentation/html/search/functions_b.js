var searchData=
[
  ['saltandpepper_0',['SaltAndPepper',['../class_image.html#a009b56a62c9f0b5cf73db6f9ba4882a2',1,'Image']]],
  ['saveimage_1',['saveImage',['../class_image.html#a22feda7f0d758ff9badd42ea02e63ae0',1,'Image']]],
  ['saveimages_2',['saveImages',['../class_volume.html#a438d8ba510bfe606d4601c3c90a8c7c0',1,'Volume']]],
  ['scharrdetection_3',['scharrDetection',['../class_image.html#ab3367e4f551b0513bfee437edb909511',1,'Image']]],
  ['scharrfilter_4',['scharrFilter',['../class_filter.html#ae1b3b46b7101e298b3986befbf064169',1,'Filter']]],
  ['setfolderpath_5',['setFolderPath',['../class_volume.html#a42f9557f84216e312567dde05ce147da',1,'Volume']]],
  ['setimages_6',['setImages',['../class_volume.html#a08e17ba6a0ff59d03119b097e7eb3dd1',1,'Volume']]],
  ['slice3dvolume_7',['slice3DVolume',['../class_volume.html#ad7833bf12d7024343356631a3137b77e',1,'Volume']]],
  ['sobeldetection_8',['sobelDetection',['../class_image.html#a952e7eff32405991820d27dfac62f0f2',1,'Image']]],
  ['sobelfilter_9',['sobelFilter',['../class_filter.html#a5549ba47c0b9d30f56cc3ed1a388ee1e',1,'Filter']]]
];
