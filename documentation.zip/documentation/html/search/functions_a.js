var searchData=
[
  ['robertscrossdetection_0',['robertsCrossDetection',['../class_image.html#abffd36c22ab24aea6d7c1a1963f5da73',1,'Image']]],
  ['robertscrossfilter_1',['robertsCrossFilter',['../class_filter.html#abb47d9f06300109c87494e42436eabdb',1,'Filter']]]
];
