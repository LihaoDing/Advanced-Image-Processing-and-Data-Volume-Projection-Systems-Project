var searchData=
[
  ['boxfilter_0',['boxFilter',['../class_image.html#a23878eff3b8330e93e07de6e7d79230d',1,'Image']]],
  ['brightness_1',['Brightness',['../class_image.html#aa67210db8b44a31f8d58e68ce03f39f1',1,'Image']]]
];
