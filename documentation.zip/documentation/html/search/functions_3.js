var searchData=
[
  ['filter_0',['Filter',['../class_filter.html#ad15994c30d497afd567a6445446a249e',1,'Filter']]]
];
