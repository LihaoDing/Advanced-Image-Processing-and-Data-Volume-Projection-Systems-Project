var indexSectionsWithContent =
{
  0: "123abcdefghilmprstuv",
  1: "fipsv",
  2: "abefghilmprstv",
  3: "agpr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

