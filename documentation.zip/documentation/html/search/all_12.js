var searchData=
[
  ['upload_20data_0',['1.2 Start - Upload data',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['using_1',['Instruction for using',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
