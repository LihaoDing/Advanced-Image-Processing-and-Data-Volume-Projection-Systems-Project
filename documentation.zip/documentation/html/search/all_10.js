var searchData=
[
  ['saltandpepper_0',['SaltAndPepper',['../class_image.html#a009b56a62c9f0b5cf73db6f9ba4882a2',1,'Image']]],
  ['saveimage_1',['saveImage',['../class_image.html#a22feda7f0d758ff9badd42ea02e63ae0',1,'Image']]],
  ['saveimages_2',['saveImages',['../class_volume.html#a438d8ba510bfe606d4601c3c90a8c7c0',1,'Volume']]],
  ['scans_3',['CT Scans',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['scharrdetection_4',['scharrDetection',['../class_image.html#ab3367e4f551b0513bfee437edb909511',1,'Image']]],
  ['scharrfilter_5',['scharrFilter',['../class_filter.html#ae1b3b46b7101e298b3986befbf064169',1,'Filter']]],
  ['setfolderpath_6',['setFolderPath',['../class_volume.html#a42f9557f84216e312567dde05ce147da',1,'Volume']]],
  ['setimages_7',['setImages',['../class_volume.html#a08e17ba6a0ff59d03119b097e7eb3dd1',1,'Volume']]],
  ['slice_8',['Slice',['../class_slice.html',1,'']]],
  ['slice3dvolume_9',['slice3DVolume',['../class_volume.html#ad7833bf12d7024343356631a3137b77e',1,'Volume']]],
  ['sobeldetection_10',['sobelDetection',['../class_image.html#a952e7eff32405991820d27dfac62f0f2',1,'Image']]],
  ['sobelfilter_11',['sobelFilter',['../class_filter.html#a5549ba47c0b9d30f56cc3ed1a388ee1e',1,'Filter']]],
  ['start_12',['1. START',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['start_20model_20choose_13',['1.1 Start - model choose',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['start_20upload_20data_14',['1.2 Start - Upload data',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['stbi_5fio_5fcallbacks_15',['stbi_io_callbacks',['../structstbi__io__callbacks.html',1,'']]]
];
