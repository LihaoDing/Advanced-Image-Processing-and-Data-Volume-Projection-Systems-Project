var searchData=
[
  ['image_0',['Image',['../class_image.html',1,'Image'],['../class_image.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()']]],
  ['installation_20and_20tests_1',['Installation and Tests',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['instruction_20for_20using_2',['Instruction for using',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
