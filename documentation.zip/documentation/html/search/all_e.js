var searchData=
[
  ['prewittdetection_0',['prewittDetection',['../class_image.html#ad609ce7b2fc0fea951a019471ecf5113',1,'Image']]],
  ['prewittfilter_1',['prewittFilter',['../class_filter.html#ade45763af47b9dbaddd806c8450cc5f7',1,'Filter']]],
  ['programming_20group_20project_2',['Advanced Programming Group Project',['../md__r_e_a_d_m_e.html',1,'']]],
  ['project_3',['Advanced Programming Group Project',['../md__r_e_a_d_m_e.html',1,'']]],
  ['projection_4',['Projection',['../class_projection.html',1,'Projection'],['../class_projection.html#ac529acc3881f040d459186a412d5ab39',1,'Projection::Projection()']]]
];
