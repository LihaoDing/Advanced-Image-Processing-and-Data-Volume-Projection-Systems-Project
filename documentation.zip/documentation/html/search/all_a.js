var searchData=
[
  ['histogramequalization_0',['HistogramEqualization',['../class_image.html#a95e62e85373c87d46876e934074ae901',1,'Image']]]
];
