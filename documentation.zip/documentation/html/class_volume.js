var class_volume =
[
    [ "Volume", "class_volume.html#a7d3bb81da95df85009b9f3ddd985cd9f", null ],
    [ "applyGaussianFilter", "class_volume.html#a2e6a27e705b2115733d1ce69c7080d06", null ],
    [ "applyMedianFilter", "class_volume.html#a05ee5ce171814f5951ec41bd1057f03c", null ],
    [ "AverageProjection", "class_volume.html#a164e89b9249352674b73cbef0421b859", null ],
    [ "AverageProjectionMedian", "class_volume.html#a487aa0c0e2b55052036a8a7f6aeca749", null ],
    [ "getChannels", "class_volume.html#a5a445744411b9ff7fcf26931c4e6afe9", null ],
    [ "getExist", "class_volume.html#afcb788195c9acac7ad533ae2109c4c85", null ],
    [ "getFolderPath", "class_volume.html#a309d73c2510fdaaeea51db6cf9f84975", null ],
    [ "getHeight", "class_volume.html#a7ac4d95f8f1ba5f1194c1c416efc1624", null ],
    [ "getImages", "class_volume.html#a87af43ee6949bb49d43e1b704d5f157c", null ],
    [ "getWidth", "class_volume.html#a04bbfbb1c84cb96c9eb879d88e85a00e", null ],
    [ "loadImages", "class_volume.html#ab6b748b5ddf219d77aba92488a134bf9", null ],
    [ "MaxProjection", "class_volume.html#a59cc0dad1bd15d2cf0010dbaa0b7306c", null ],
    [ "MinProjection", "class_volume.html#a871cd67494f011f081c069c68c83fdb0", null ],
    [ "saveImages", "class_volume.html#a438d8ba510bfe606d4601c3c90a8c7c0", null ],
    [ "setFolderPath", "class_volume.html#a42f9557f84216e312567dde05ce147da", null ],
    [ "setImages", "class_volume.html#a08e17ba6a0ff59d03119b097e7eb3dd1", null ],
    [ "slice3DVolume", "class_volume.html#ad7833bf12d7024343356631a3137b77e", null ]
];