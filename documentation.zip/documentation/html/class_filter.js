var class_filter =
[
    [ "Filter", "class_filter.html#ad15994c30d497afd567a6445446a249e", null ],
    [ "apply2DGaussianFilter", "class_filter.html#a8fa29694dc85c73439082086725c0101", null ],
    [ "apply2DMedianBlurFilter", "class_filter.html#ae87b23b3ae888be94bd908dfdcda65ca", null ],
    [ "apply3DGaussianFilter", "class_filter.html#a99d667ae2dbe0289161200f4291084f0", null ],
    [ "apply3DMedianFilter", "class_filter.html#a9cc9553906f27113fdf6483a79d8d55b", null ],
    [ "applyBoxBlur", "class_filter.html#ac54cf1fc0f05a146767d3f703c5c431a", null ],
    [ "applyBrightnessFilter", "class_filter.html#ad2b2e9a510b8adac0c589a1571d294b5", null ],
    [ "applyGrayscaleFilter", "class_filter.html#a51f864482699e8990f76c5c23c483f15", null ],
    [ "applyHistogramEqualization", "class_filter.html#a224a6536a583a12d06f568da794cd2dc", null ],
    [ "applySpFilter", "class_filter.html#aa640e1438f5bb678455146096926969a", null ],
    [ "applyThresholdFilter", "class_filter.html#a8cb95e859e386937660f7ea16f3cc049", null ],
    [ "prewittFilter", "class_filter.html#ade45763af47b9dbaddd806c8450cc5f7", null ],
    [ "robertsCrossFilter", "class_filter.html#abb47d9f06300109c87494e42436eabdb", null ],
    [ "scharrFilter", "class_filter.html#ae1b3b46b7101e298b3986befbf064169", null ],
    [ "sobelFilter", "class_filter.html#a5549ba47c0b9d30f56cc3ed1a388ee1e", null ]
];