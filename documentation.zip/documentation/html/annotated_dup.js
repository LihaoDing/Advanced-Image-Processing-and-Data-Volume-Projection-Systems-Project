var annotated_dup =
[
    [ "Filter", "class_filter.html", "class_filter" ],
    [ "Image", "class_image.html", "class_image" ],
    [ "Projection", "class_projection.html", "class_projection" ],
    [ "Slice", "class_slice.html", "class_slice" ],
    [ "stbi_io_callbacks", "structstbi__io__callbacks.html", null ],
    [ "Volume", "class_volume.html", "class_volume" ]
];