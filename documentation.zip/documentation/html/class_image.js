var class_image =
[
    [ "Image", "class_image.html#a58edd1c45b4faeb5f789b0d036d02313", null ],
    [ "boxFilter", "class_image.html#a23878eff3b8330e93e07de6e7d79230d", null ],
    [ "Brightness", "class_image.html#aa67210db8b44a31f8d58e68ce03f39f1", null ],
    [ "GaussianFilter", "class_image.html#a7357b545059457d5867a8bc89a168c57", null ],
    [ "getChannels", "class_image.html#a074132850b855562d55cd7246a993141", null ],
    [ "getExist", "class_image.html#a14868bae168814b70240f6f36efe9c81", null ],
    [ "getHeight", "class_image.html#aa4e1f064e5e1f3f04ad605408f1ec3af", null ],
    [ "getPath", "class_image.html#a885989eb723cb0a1fc0555c7e8de817e", null ],
    [ "getWidth", "class_image.html#af2720a072812763395512fc3c8c21362", null ],
    [ "Grayscale", "class_image.html#a574fddf6258210ca7aa310439d9505f7", null ],
    [ "HistogramEqualization", "class_image.html#a95e62e85373c87d46876e934074ae901", null ],
    [ "loadImage", "class_image.html#afb7f6a9d713c9e9277efefa360d7c3c0", null ],
    [ "MedianFilter", "class_image.html#a2321efeb6058ebb678b2add732001198", null ],
    [ "prewittDetection", "class_image.html#ad609ce7b2fc0fea951a019471ecf5113", null ],
    [ "robertsCrossDetection", "class_image.html#abffd36c22ab24aea6d7c1a1963f5da73", null ],
    [ "SaltAndPepper", "class_image.html#a009b56a62c9f0b5cf73db6f9ba4882a2", null ],
    [ "saveImage", "class_image.html#a22feda7f0d758ff9badd42ea02e63ae0", null ],
    [ "scharrDetection", "class_image.html#ab3367e4f551b0513bfee437edb909511", null ],
    [ "sobelDetection", "class_image.html#a952e7eff32405991820d27dfac62f0f2", null ],
    [ "Threshold", "class_image.html#a13147d9a2ac149babdf614ba32f91282", null ]
];