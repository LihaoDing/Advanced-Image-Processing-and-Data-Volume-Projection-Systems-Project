var class_slice =
[
    [ "extractAndSaveSlice", "class_slice.html#a7261c0866a080009a9cc92ee8ac46fb6", null ]
];