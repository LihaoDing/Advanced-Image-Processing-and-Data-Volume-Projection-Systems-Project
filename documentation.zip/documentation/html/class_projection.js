var class_projection =
[
    [ "Projection", "class_projection.html#ac529acc3881f040d459186a412d5ab39", null ],
    [ "AIP", "class_projection.html#a5065cae3b21fdd8196ec2412b24f4aa8", null ],
    [ "AIPMedian", "class_projection.html#a2c05179b241f2a798fb085730fe7f922", null ],
    [ "MinIP", "class_projection.html#a794b5530b359b6fa0e5e13caebc5429c", null ],
    [ "MIP", "class_projection.html#a722363c1b7b5afd4d70b5a6065e22fe0", null ]
];